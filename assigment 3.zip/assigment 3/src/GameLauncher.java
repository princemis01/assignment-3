import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class GameLauncher {
    private static MonsterManager monsterManager = new MonsterManager();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Main Menu:");
            System.out.println("1. Create Monster");
            System.out.println("2. View Monsters");
            System.out.println("3. Breed Monsters");
            System.out.println("4. Save Game");
            System.out.println("5. Load Game");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createMonster();
                    break;
                case 2:
                    viewMonsters();
                    break;
                case 3:
                    breedMonsters();
                    break;
                case 4:
                    saveGame();
                    break;
                case 5:
                    loadGame();
                    break;
                case 6:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void createMonster() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter color: ");
        String color = scanner.nextLine();
        System.out.print("Enter strength: ");
        int strength = scanner.nextInt();
        System.out.print("Enter speed: ");
        int speed = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Monster monster = new Monster(name, color, strength, speed) {
            @Override
            public void performSpecialAbility() {
                // default implementation
            }
        };

        monsterManager.addMonster(monster);
        System.out.println("Monster created successfully!");
    }

    private static void viewMonsters() {
        monsterManager.displayMonsters(true);
    }

    private static void breedMonsters() {
        // Implement breeding process
    }

    private static void saveGame() {
        try {
            FileManager.saveMonsters(monsterManager.getMonsters(), "monsters_data.txt");
            System.out.println("Game saved successfully!");
        } catch (IOException e) {
            System.out.println("Error saving game: " + e.getMessage());
        }
    }

    private static void loadGame() {
        try {
            monsterManager.setMonsters(FileManager.loadMonsters("monsters_data.txt"));
            System.out.println("Game loaded successfully!");
        } catch (FileNotFoundException e) {
            System.out.println("Error loading game: File not found.");
        } catch (IOException e) {
            System.out.println("Error loading game: " + e.getMessage());
        }
    }
}
