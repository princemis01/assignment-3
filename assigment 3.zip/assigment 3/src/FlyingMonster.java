import java.io.BufferedWriter;
import java.io.IOException;

public class FlyingMonster extends Monster {
    private int wingSpan;

    public FlyingMonster(String name, String color, int strength, int speed, int wingSpan) {
        super(name, color, strength, speed);
        this.wingSpan = wingSpan;
    }

    @Override
    public void performSpecialAbility() {
        System.out.println(name + " is flying with wingspan of " + wingSpan + " units.");
    }

    @Override
    public void saveToFile(BufferedWriter writer) throws IOException {
        super.saveToFile(writer);
        writer.write("," + wingSpan);
    }
}
