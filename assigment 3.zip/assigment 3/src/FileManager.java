import java.io.*;
import java.util.ArrayList;

public class FileManager {
    public static void saveMonsters(ArrayList<Monster> monsters, String filename) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Monster monster : monsters) {
                monster.saveToFile(writer);
                writer.newLine();
            }
        }
    }

    public static ArrayList<Monster> loadMonsters(String filename) throws IOException {
        ArrayList<Monster> monsters = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) {
            throw new FileNotFoundException("File not found: " + filename);
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                monsters.add(Monster.loadFromFile(new BufferedReader(new StringReader(line))));
            }
        }
        return monsters;
    }
}
