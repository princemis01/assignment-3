import java.util.ArrayList;

public class MonsterManager {
    private ArrayList<Monster> monsters;

    public MonsterManager() {
        monsters = new ArrayList<>();
    }

    public void addMonster(Monster monster) {
        monsters.add(monster);
    }

    public void breedMonsters(int index1, int index2) {
        // Implement breeding logic
    }

    public void saveGame(String filename) {
        // Implement save logic
    }

    public void loadGame(String filename) {
        // Implement load logic
    }

    public void displayMonsters(boolean detailed) {
        for (Monster monster : monsters) {
            System.out.println(monster);
        }
    }

    public ArrayList<Monster> getMonsters() {
        return monsters;
    }

    public void setMonsters(ArrayList<Monster> monsters) {
        this.monsters = monsters;
    }
}
